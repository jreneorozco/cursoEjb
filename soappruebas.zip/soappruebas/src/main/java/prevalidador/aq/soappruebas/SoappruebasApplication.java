package prevalidador.aq.soappruebas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoappruebasApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoappruebasApplication.class, args);
	}
}
