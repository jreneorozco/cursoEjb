package mx.com.itce.AeroRespuestas_2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AeroRespuestas2Application {

	public static void main(String[] args) {
		SpringApplication.run(AeroRespuestas2Application.class, args);
	}
}
